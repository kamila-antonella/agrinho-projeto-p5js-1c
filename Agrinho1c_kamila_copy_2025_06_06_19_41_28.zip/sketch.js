// Adicione uma constante para a temperatura máxima
const TEMPERATURA_MAXIMA = 40; // Exemplo de limite de temperatura

// No seu loop draw(), adicione a verificação:
function draw() {
  // ... seu código existente ...

  if (temperatura >= TEMPERATURA_MAXIMA) {
    // Fim de jogo por temperatura
    textSize(40);
    fill(255, 0, 0); // Texto vermelho
    textAlign(CENTER, CENTER);
    text("GAME OVER!", width / 2, height / 2);
    text("A floresta secou!", width / 2, height / 2 + 50);
    noLoop(); // Para o loop draw, congelando o jogo
  }
}